export default {
  value: '123,456',
  saleList: [
    { date: 1, value: 3, num: 1 },
    { date: 2, value: 9, num: 2 },
    { date: 3, value: 5, num: 2 },
    { date: 4, value: 8, num: 2 },
    { date: 5, value: 11, num: 2 },
    { date: 6, value: 6, num: 2 },
    { date: 7, value: 8, num: 2 },
    { date: 8, value: 7, num: 2 },
  ],
  dailySale: '10',
};
