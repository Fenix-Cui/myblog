export default {
  value: '82,234',
  saleList: [
    { type: 'a', value: 3 },
    { type: 'b', value: 9 },
  ],
  dailySale: '10',
};
