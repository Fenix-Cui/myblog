export default {
  value: '999,999',
  saleList: [
    { date: 1, value: 3 },
    { date: 2, value: 9 },
    { date: 3, value: 5 },
    { date: 4, value: 8 },
    { date: 5, value: 11 },
    { date: 6, value: 6 },
    { date: 7, value: 8 },
    { date: 8, value: 7 },
  ],
  dailySale: '¥991,234',
};
