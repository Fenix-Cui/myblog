export default {
  'app.i18n.demo': 'i18n demo',
  'app.i18n.content': 'The card is an example for switch i18n.',
};
