export default {
  'app.i18n.demo': '多语言示例',
  'app.i18n.content': '本区块用来展示多语言切换能力',
};
