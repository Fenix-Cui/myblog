const APP_MODE = (global as any).__app_mode__ || process.env.APP_MODE;

export default APP_MODE;
