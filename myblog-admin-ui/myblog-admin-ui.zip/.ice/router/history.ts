// https://github.com/ReactTraining/history/blob/master/modules/index.js
export {
  createBrowserHistory,
  createHashHistory,
  createMemoryHistory
} from 'history';
