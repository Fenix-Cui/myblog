import * as React from 'react';

import store from 'D:/WebSite Folder/Fenix_Blog/myblog-admin-ui/src/pages/Solution/store';

import PageComponent from 'D:/WebSite Folder/Fenix_Blog/myblog-admin-ui/src/pages/Solution';

const PageComponentName = PageComponent;

const PageProvider = store.Provider;
const StoreWrapperedPage = (props) => {
  return (
    <PageProvider>
      <PageComponentName {...props} />
    </PageProvider>
  );
};
(StoreWrapperedPage as any).pageConfig =
  (PageComponentName as any).pageConfig || ({} as any);
export default StoreWrapperedPage;
export { store };
