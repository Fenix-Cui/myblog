import * as React from 'react';

import PageComponent from 'D:/WebSite Folder/Fenix_Blog/myblog-admin-ui/src/pages/FusionActionTable';

const PageComponentName = PageComponent;

export default PageComponentName;
