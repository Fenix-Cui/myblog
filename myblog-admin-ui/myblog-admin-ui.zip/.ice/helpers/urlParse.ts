import * as urlParse from 'url-parse';

export {
  urlParse
};
