import { urlParse } from './urlParse';
import { cookie } from './cookie';

const helpers = {
  cookie, urlParse
};

// TODO: 只留一个
export {
  helpers
};
export default helpers;
