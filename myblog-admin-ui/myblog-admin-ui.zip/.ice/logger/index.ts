import * as logger from 'loglevel';

export default logger;