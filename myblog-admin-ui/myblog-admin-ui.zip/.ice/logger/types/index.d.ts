export interface ILogger {
    level: string;
}
