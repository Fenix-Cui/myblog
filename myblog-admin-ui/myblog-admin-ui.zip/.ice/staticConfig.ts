let staticConfig = {};

try {
} catch (error) {
  // ignore error
}

// @ts-ignore
export default staticConfig.__esModule ? staticConfig.default : staticConfig;
