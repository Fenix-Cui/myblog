function loadStaticModules(appConfig) {
  require('D:/WebSite Folder/Fenix_Blog/myblog-admin-ui/node_modules/build-plugin-ice-request/lib/runtime.js').default(
    { appConfig }
  );
}

export default loadStaticModules;
