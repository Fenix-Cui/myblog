export interface IAuth {
  NoAuthFallback?: React.ReactNode;
}
