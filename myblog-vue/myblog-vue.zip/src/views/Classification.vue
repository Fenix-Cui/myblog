<template>
  <div>
    <div class="block">
      <p class="tips">xxxxxxxxxxxxxxxxxxx</p>

      <el-carousel indicator-position="outside" v-bind:height="this.h_px+'px'" :style="{width: w_px()+'px'}">
        <el-carousel-item v-for="img_list in img_lists" :key="img_list">
          <el-image :src="img_list" @click="img_url(img_list)"></el-image>
        </el-carousel-item>
      </el-carousel>
    </div>
  </div>
</template>

<script>
    export default {
      name: "Classification",
      data:{

      },
      data(){
        return{
          img_lists:[
            "static/images/java.png",
            "static/images/python.png"
          ],
          h_px: 400,
        }
      },
      methods:{
        img_url(value){
          // 获取图片对应网址的参数，如java python...
          let index = value.lastIndexOf("\/");
          let data = value.substring(index + 1,value.length-4);

          this.$router.push({
            path: "/main",  // 将要跳转的页面
            query: {data: data}  // 传递的值
          })
        },
        // 使宽度和高度等比例缩放
        w_px(){
          let w_line = this.h_px/0.5625
          return w_line
        },
      }
    }

</script>

<style scoped>
  .tips{
    text-align: center;
  }
  .el-image {
    width: 100%;
    height: 100%;
  }
  .el-image img{
    width: 100%;
    height: 100%;
  }
  .el-carousel{
    margin: 0 auto;

  }
  .el-carousel {
    align-items: center;
    justify-content: center;
    text-align: center;
  }
  .el-carousel__item {
    color: #475669;
    font-size: 14px;
    opacity: 0.50;
    line-height: 150px;
    margin: 0;
  }

  .el-carousel__item:nth-child(2n) {
    background-color: #99a9bf;
  }

  .el-carousel__item:nth-child(2n+1) {
    background-color: #d3dce6;
  }
  /*img{*/
  /*  !*width: 100%;*!*/
  /*  height: inherit;*/
  /*}*/
</style>
