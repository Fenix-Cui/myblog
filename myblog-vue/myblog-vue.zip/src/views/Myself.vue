<template>
  <div>
    <span v-for="i in 100">{{i}}<br/></span>
  </div>
</template>

<script>
  export default {
    name: "Myself",
    components: {

    },
    data(){

    }
  }
</script>

<style scoped>

</style>
