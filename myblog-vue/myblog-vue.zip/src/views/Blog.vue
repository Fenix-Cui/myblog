<template>
  <div>
    <div class="main">
      <div class='content' v-html="content"></div>
    </div>
  </div>
</template>

<script>
  import axios from "axios";

  export default {
    name: "Blog",
    data() {
      return {
        author: "",
        category: "",
        content: "",
        id: "",
        love: "",
        message: "",
        title: "",
        create_time: "",
        update_time: "",
      };
    },
    mounted() {
      let title = this.$route.query.title; //初始化时将form Dom对象传入
      let formData = new FormData(); //初始化时将form Dom对象传入
      formData.append('title', title);
      axios.post("http://localhost:9000/http/main/getOrderBlog", formData)
      .then((res)=>{
        this.id = res.data.id;
        this.title = res.data.title;
        this.author = res.data.author;
        this.category = res.data.category;
        this.content = res.data.content;
        this.create_time = res.data.create_time;
        this.update_time = res.data.update_time;
        this.love = res.data.love;
      })
    }
  }
</script>

<style >
 .content{
   /*text-align: center;*/
   margin: 0 20% 0 20%;
   word-break: break-all;
   white-space: normal;
 }

 code {
   white-space: normal;
   word-break: break-all;
 }

</style>
