<template>
  <div class="body-bg">
    <!-- Main -->
    <div class="main">
      <span>{{mainTitle}}<br/></span>
      <span v-for="title in mainTitle"><button @click="titleClick(title)" >{{title}}</button></span>
    </div>

    <br/>
    <br/>
    <br/>

    <!-- footer -->
    <div class="footer">
      <p class="copyright">&copy; Created. Design: Fenix.Cui</p>
      <!-- 备案 -->
      <div style="margin:0 auto; padding:20px 0;">
        <img src="static/images/filing-icon.png" /><a target="_blank" href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=11010502043277" style="display:inline-block;text-decoration:none;height:20px;line-height:20px;"><img src="" style="float:left;"/><p style="float:left;height:20px;line-height:20px;margin: 0px 0px 0px 5px; color:#939393;">京公网安备 11010502043277号</p></a>
      </div>
    </div>
  </div>
</template>

<script>
  import axios from "axios"

  export default {
    name: "Main",
    data() {
      return {
        activeIndex: '1',
        mainTitle: [],
      };
    },
    methods:{
      titleClick(title){
        this.$router.push({
          path: "/blog",  // 将要跳转的页面
          query: {title: title}  // 传递的值
        })
      }
    },
    mounted() {
      let formData = new FormData(); //初始化时将form Dom对象传入
      formData.append('data', this.$route.query.data);
      axios.post("http://localhost:9000/http/main/getMainTitle", formData)
      // .then((res)=>{
      // this.mainTitle = res.data
      // })
      .then((res)=>{
        for (let i = 0; i < res.data.length; i++) {
          this.mainTitle.push(res.data[i]["title"])
        }
      })
    }
  }

</script>

<style scoped lang="css">

  /*main*/
  .main, .title_list {
    background-color: rgba(255,255,255,0.2);
    color: #000000;  /*文本颜色*/
    text-align: center;
    /*line-height: 160px;*/
    width: 100%;
  }
  .title_list{
    /*background-color: coral;*/
    /*width: 50%;*/
    height: auto;
    overflow: hidden;
    /*float: left;*/
  }

  /*footer*/
  .footer {
    text-align: center;
    overflow: unset;
    /*position: absolute;*/
    bottom: 0;
    width: 100%;
    /*height: 60px;*/
  }
</style>
